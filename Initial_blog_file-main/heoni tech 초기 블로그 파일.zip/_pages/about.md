---
title:  "내 피 땀 눈물이 들어간 블로그를 만들며"
permalink: /about/
layout: single
published: true
date: 2021-09-25
categories:
  - Blog
tags:
  - Blog
---


### 나에 대하여 설명하자. 

1. 본인의 경력, 수상 그리고 프로젝트 등을 작성하여 포트폴리오로 활용한다. 

2. 블로그를 운영하는 각오나 방향성에 대하여 작성한다. 

3. 나란 사람은 어떤 사람이다! 라고 작성한다 

등등~~